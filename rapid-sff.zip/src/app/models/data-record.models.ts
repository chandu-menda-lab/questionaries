interface DataRecord {
    ID: number;
    Name: string;
    Age: number;
    Country: string;
    [key: string]: any;
}