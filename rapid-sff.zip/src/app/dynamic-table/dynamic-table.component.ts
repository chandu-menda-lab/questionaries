import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

interface DataRecord {
  ID: number;
  Name: string;
  Age: number;
  Country: string;
  [key: string]: any;
}

@Component({
  selector: 'app-dynamic-table',
  templateUrl: './dynamic-table.component.html',
  styleUrls: ['./dynamic-table.component.css']
})
export class DynamicTableComponent implements OnInit {
  data: DataRecord[] = []; // Array to hold the actual data records
  filteredData = new MatTableDataSource<DataRecord>();
  
  displayedColumns: string[] = []; // Array to hold the header columns
  filterValues: { [key: string]: string } = {};  // Holds the filter values for each column
  dataSource = new MatTableDataSource<any>();
  isFilterVisible: boolean = true;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  
  filterOptions1 = ['Option 1', 'Option 2', 'Option 3'];
  filterOptions2 = ['Option A', 'Option B', 'Option C'];
  filterOptions3 = ['Option X', 'Option Y', 'Option Z'];

  filterSearch1 = '';
  filterSearch2 = '';
  filterSearch3 = '';

  selectedFilter1 = '';
  selectedFilter2 = '';
  selectedFilter3 = '';

  leftPanelOpen = true;

  ngOnInit(): void {
    this.loadData();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  loadData() {
    // API call to fetch data
    // Assuming the first row contains headers
   // Simulated API response, separate headers from records
   const apiResponse = this.fetchDataFromApi();

   // Extract headers (first row) and records (remaining rows)
   const headers = apiResponse.headers;
   const records = apiResponse.records;
   
   this.displayedColumns = headers; // Set the table's displayed columns
   this.dataSource.data = records; // Populate the data source with records

  this.dataSource.filterPredicate = this.filterPredicate.bind(this);
    // Initialize filter values
    this.displayedColumns.forEach(column => {
      this.filterValues[column] = '';
    });
  }

  fetchDataFromApi() {
    // Replace this with an actual API call
    return {
      headers: ['ID', 'Name', 'Age', 'Country', 'Email', 'Phone', 'City', 'State', 'Zip', 'Notes'],
      records: [
        { ID: 1, Name: 'John', Age: 25, Country: 'USA', Email: 'john@example.com', Phone: '1234567890', City: 'New York', State: 'NY', Zip: '10001', Notes: 'Sample note 1' },
        { ID: 2, Name: 'Jane', Age: 30, Country: 'UK', Email: 'jane@example.com', Phone: '0987654321', City: 'London', State: 'LDN', Zip: 'E1 6AN', Notes: 'Sample note 2' },
        { ID: 3, Name: 'Alice', Age: 22, Country: 'Canada', Email: 'alice@example.com', Phone: '1231231234', City: 'Toronto', State: 'ON', Zip: 'M5G 2C3', Notes: 'Sample note 3' },
        { ID: 4, Name: 'Bob', Age: 28, Country: 'Australia', Email: 'bob@example.com', Phone: '3213214321', City: 'Sydney', State: 'NSW', Zip: '2000', Notes: 'Sample note 4' }
      ]
    };
  }

  applyFilters() {
    // Apply filters to data and update filteredData
    this.filteredData.data = this.data.slice(1).filter(record => {
      return (!this.selectedFilter1 || record['someField'] === this.selectedFilter1) &&
             (!this.selectedFilter2 || record['someField'] === this.selectedFilter2) &&
             (!this.selectedFilter3 || record['someField'] === this.selectedFilter3);
    });
  }

  toggleLeftPanel() {
    this.leftPanelOpen = !this.leftPanelOpen;
  }

  previewData() {
    // Implement preview logic
  }

  onPaginateChange(event: any) {
    // Handle pagination logic
  }

  applyFilter() {
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }

  filterPredicate(data: any, filter: string): boolean {
    const filterValues = JSON.parse(filter);
    let matchesFilter = true;

    for (const key in filterValues) {
      if (filterValues[key]) {
        const dataValue = data[key] !== undefined ? data[key].toString().toLowerCase() : '';
        const filterValue = filterValues[key].toString().toLowerCase();
        
        matchesFilter = matchesFilter && dataValue.includes(filterValue);
      }
    }

    return matchesFilter;
  }


  getUniqueValues(column: string): string[] {
    return Array.from(new Set(this.dataSource.data.map(item => item[column])));
  }
}
