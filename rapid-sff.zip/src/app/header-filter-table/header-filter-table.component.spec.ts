import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderFilterTableComponent } from './header-filter-table.component';

describe('HeaderFilterTableComponent', () => {
  let component: HeaderFilterTableComponent;
  let fixture: ComponentFixture<HeaderFilterTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderFilterTableComponent]
    });
    fixture = TestBed.createComponent(HeaderFilterTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
