import { Component, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-header-filter-table',
  templateUrl: './header-filter-table.component.html',
  styleUrls: ['./header-filter-table.component.css']
})
export class HeaderFilterTableComponent {
  // filteredData = new MatTableDataSource<DataRecord>();
  // data: DataRecord[] = []; // Array to hold the actual data records

  // @Input() selectedFilter1: any;
  // @Input() filterOptions1: any;
  // @Input() filterSearch1:any;

  // @Input() selectedFilter2: any;
  // @Input() filterOptions2: any;
  // @Input() filterSearch2:any;

  // @Input() selectedFilter3: any;
  // @Input() filterOptions3: any;
  // @Input() filterSearch3:any;

  // applyFilters() {
  //   // Apply filters to data and update filteredData
  //   this.filteredData.data = this.data.slice(1).filter(record => {
  //     return (!this.selectedFilter1 || record['someField'] === this.selectedFilter1) &&
  //            (!this.selectedFilter2 || record['someField'] === this.selectedFilter2) &&
  //            (!this.selectedFilter3 || record['someField'] === this.selectedFilter3);
  //   });
  // }

  // previewData() {
  //   // Implement preview logic
  // }


}
